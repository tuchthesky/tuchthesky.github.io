 tuchthesky.github.io
 <!DOCTYPE html>
# <html lang="ru">
# <head>
#	<meta charset="UTF-8">
#	<meta name="viewport" content="width=device-width, initial-scale=1.0">
#	
#	<link rel="stylesheet" type="text/css" hreflang="https://fonts.googleapis.com/css2?family=Vollkorn+SC&display=swap"
#   rel="stylesheet">
#	<link rel="stylesheet" href="C:\Users\Home\Desktop\prjct\newyear\css\cascad.css">
# </head>
# <body>
# <header class="section">
#	<div class="container">
#		<div class="nav">
#				   <a href="">
#					<img src="C:\Users\Home\Desktop\prjct\newyear\html\Goo.jpg" width="60px" height="60-px">
#				   </a>
#			   
#			   <a href="mailto:Powerline33377@gmail.com" class="mail">
#			   		<img src="C:\Users\Home\Desktop\prjct\newyear\html\Gmail.png" width="50px"
#			   	height="50px">
#
#			   </a>
#          
#		</div>
#		<div class="header-content">	
#			<div class="content-wripper">
#						        <div class="offer">
#					                <p class="place">
#					                o.Бали	
#					                </p>
#					                  <H1 class="offer-title">
#					                  	FREELANCE CAMP
#					                  </H1>
#					                <p class="desc">
#					                    Мечта свободного верстальщика
#					                </p>
#					                <a href="#" class="btn">Узнать больше</a>
#					           </div>
#
#					           <div class="intro">
#					           	<h4 class="intro-title">
#					           		Что там?
#					           	</h4>
#					           	<p>
#					           		Рай на земле. Только для верстальщиков, которые осмелятся отправиться на # другой конец земли в поисках свободы, успеха и  счастья.
#					           	</p>
#
#					           </div>
#           </div>
#
#           <img src="C:\Users\Home\Desktop\prjct\newyear\html\bali.jpg" alt="dreams" class="bali-amg" width="300px" height="450px">
#	    </div>
#    </div>
# </header>
# </body>
# </html>
